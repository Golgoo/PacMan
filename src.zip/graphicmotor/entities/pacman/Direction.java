package graphicmotor.entities.pacman;

public enum Direction {
	HAUT, BAS ,
	DROITE, GAUCHE ,

}
