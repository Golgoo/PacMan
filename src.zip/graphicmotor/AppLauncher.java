package graphicmotor;

public class AppLauncher {

	public static void main(String[] args) {
		new MainFrame().setVisible(true); 
	}

}
