
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;

import graphicmotor.GooContext;
import inputs.InputMotor;
import model.game.GameModel;
import model.launcher.LauncherModel;
import model.menu.MenuModel;
import physic.*;
import singletons.*;
import kernel.*;


public class Main {
	
	/**
	 * PARAMETERS *****************
	 */
	//Here you can defined the main layout size
	private static int frameWidth = 720;
	
	private static int canvasHeight = 500 ;
	private static int menuHeight = 120 ;
	
	
	
	//Here you can choose the difficulty
	//Vary it between 1 and 13;
	private static int difficutly = 10 ;
	//Do not try the level 2 with difficulty 13
	
	//You can also select a skin !
	//Available skins : "classic"
	private static String skin = "classic";
	
	//Here you can select the number of levels
	private static int nbLevels = 2 ;
	//Here you can specify levels you want to play
	private static String[] selectLevels() {
		String[] levels = new String[nbLevels];
		
		for(int i = 1 ; i <= nbLevels ; i ++) {
			levels[i-1] = "ressources/levels/level"+(i)+".txt" ;
		}
		
		return levels;
	}
	
	
	//You can also specify keyboard map for commands in the class "inputs.CommandsMapLoader"
	
	//You can also specify which number correspond to which entity to build your own levels in the class "model.game.factory.LevelFactory" in function initBuilders()
	
	/**
	 * END OF PARAMETERS *******
	 */
	private static GooContext GCtx ;
	private static GooContext menuCTX;
	
	private static GameModel gameModel ;
	private static MenuModel menuModel ;
	private static LauncherModel launcherModel ;
	
	private static PhysicMotor phyMotor ;
	
	private static InputMotor inputMotor ;
	
	private static Kernel kernel ;
	
	private static JFrame mainFrame ;
	

	
	private static int frameHeight = canvasHeight + menuHeight ;
	
	private static Dimension canvasSize = new Dimension(frameWidth, canvasHeight);
	private static Dimension menuSize = new Dimension(frameWidth, menuHeight);

	
	public static void main(String[] args) {
		
		initGraphicCtx();
		
		initAWTLayout();
		
		initModel();
		
		initPhysic();
		
		initKernel();
				
		initInputMotor();

		GCtx.start(60);
		menuCTX.start(100);

		kernel.displayLauncher();
		
		GCtx.stop();
		menuCTX.stop();
	}

	private static void initGraphicCtx() {
		GCtx = new GooContext(frameWidth, canvasHeight);
		Acessors.setGctx(GCtx);

		menuCTX = new GooContext(frameWidth, menuHeight);
		Acessors.setMenuCtx(menuCTX);
	}
	

	private static void initAWTLayout() {
		mainFrame = new JFrame();
		mainFrame.setSize(frameWidth, frameHeight);

		JPanel panel = new JPanel();
		panel.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 0));
		
		panel.add(menuCTX.getCanvas());
		
		panel.add(GCtx.getCanvas());
		
		panel.setMinimumSize(new java.awt.Dimension(frameWidth, frameHeight));
		panel.setMaximumSize(new java.awt.Dimension(frameWidth, frameHeight));
		
		mainFrame.add(panel);
		
		mainFrame.setMinimumSize(new java.awt.Dimension(frameWidth, frameHeight + 25));
		mainFrame.setMaximumSize(new java.awt.Dimension(frameWidth, frameHeight + 25));
		
		mainFrame.setVisible(true);
		mainFrame.setResizable(false);
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	private static void initInputMotor() {
		inputMotor = new InputMotor(kernel);
		mainFrame.addKeyListener(inputMotor);
		Acessors.setInputMotor(inputMotor);
	}
	
	private static void initModel() {
		gameModel = new GameModel(difficutly, skin);
		Acessors.setGameModel(gameModel);
		
		menuModel = new MenuModel();
		Acessors.setMenuModel(menuModel);
		
		launcherModel = new LauncherModel();
		Acessors.setLauncherModel(launcherModel);
	}
	
	private static void initPhysic() {
		phyMotor = new PhysicMotor();
		Acessors.setPhysic(phyMotor);
	}
	
	private static void initKernel() {
		kernel = new Kernel(menuSize, canvasSize);
		String [] levels = selectLevels();
		kernel.setLevels(levels);
	}

}
