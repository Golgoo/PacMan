package util;

public enum Direction {
	UP, RIGHT, LEFT, DOWN
}
