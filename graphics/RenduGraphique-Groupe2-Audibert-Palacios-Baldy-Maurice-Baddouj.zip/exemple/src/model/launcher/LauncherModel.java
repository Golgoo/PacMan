package model.launcher;


public class LauncherModel {
	public boolean startRequired = false ;
	
	public int hightScore = 0;
	
	public void init(){
		startRequired = false ;
	}
}
