package model.game;

import java.util.LinkedList;
import java.util.List;

import model.game.entities.Entity;
import physic.Dimension;
import physic.Position;

public class GameModel {
	
	private String skin ;

	private int difficulty ;
	
	public Entity pacman ;
	public int pacmanSpeedVelocity ;
	public boolean superPacman ;
	
	public Dimension minimumPacManDim;
	public Dimension maximumPacManDim;
	
	public List<Entity> fruits ;
	public List<Entity> superFruits ;
	public List<Entity> walls ;
	public List<Entity> steroids;
	public List<Entity> bounds;
	
	public List<Entity> ghosts;
	
	int [][] matrix ;
	
	public boolean gameWon ;
	public boolean gameLoose ;
	
	public boolean gamePaused ;
	public boolean gameIsRunning ;

	public boolean steroidPacMan;

	public GameModel(int difficulty, String skin) {
		if(difficulty < 0) this.difficulty = 0 ;
		else if(difficulty > 13) this.difficulty = 13;
		else this.difficulty = difficulty ;
		this.skin = skin ;
	}

	public void init() {
		fruits = new LinkedList<Entity>() ;
		superFruits = new LinkedList<Entity>();
		walls = new LinkedList<Entity>();
		steroids = new LinkedList<Entity>();
		bounds = new LinkedList<Entity>();
		ghosts = new LinkedList<Entity>();
		gameWon = false ;
		gameLoose = false ;
		gamePaused = false ;
		superPacman = false ;
		gameIsRunning = false ;
		steroidPacMan = false ;
		matrix = null ;
	}
	
	public int width, height ;
	public double stepX, stepY ;
	public int offSetX, offSetY ;
	
	public void updateMatrix() {
		matrix = new int[height][width];
		for(int i = 0 ; i < height ; i ++) {
			for(int j = 0 ; j < width ; j ++) {
				matrix[i][j] = 1 ;
			}
		}
		for(Entity wall : walls) {
			Position matrixPosition = wall.getPhisicDatas().getMatrixPosition();
			matrix[matrixPosition.getY()][matrixPosition.getX()] = Integer.MAX_VALUE ;
		}
		for(Entity bound : bounds) {
			Position matrixPosition = bound.getPhisicDatas().getMatrixPosition();
			matrix[matrixPosition.getY()][matrixPosition.getX()] = Integer.MAX_VALUE ;
		}
		for(Entity ghost : ghosts) {
			Position matrixPosition = ghost.getPhisicDatas().getMatrixPosition();
			matrix[matrixPosition.getY()][matrixPosition.getX()] = difficulty * 20 + 2;
		}
		for(Entity fruit : fruits) {
			Position matrixPosition = fruit.getPhisicDatas().getMatrixPosition();
			matrix[matrixPosition.getY()][matrixPosition.getX()] = 0 ;
		}
	}
	
	public int[][] getMatrix() {
		return matrix ;
	}
	
	public void setSkin(String skin) {
		this.skin = skin ;
	}

	public String getSkin() {
		return skin ;
	}

}
