package model.game.factory;

import graphicmotor.GooContext;
import kernel.GhostCollidePacMan;
import kernel.Kernel;
import model.game.GameModel;
import model.game.PhisicDatas;
import model.game.entities.Entity;
import model.game.entities.Ghost;
import physic.Dimension;
import physic.PhysicMotor;
import physic.Position;
import physic.Velocity;

public class GhostBuilder extends EntityBuilder {
	
	private double ghostRatio = 0.8;
	private double ghostOffset = 0.5 - ( ghostRatio / 2.0);

	public GhostBuilder(PhysicMotor phyMotor, Kernel kernel, GooContext GCtx, GameModel gameModel) {
		super(phyMotor, kernel, GCtx, gameModel);
	}

	@Override
	protected PhisicDatas computePhysicData(Position position, double stepX, double stepY, Position matrixPosition) {
		position.setX(position.getX()+1 + (int)(ghostOffset*stepX));
		position.setY(position.getY()+1 + (int)(ghostOffset*stepY));
		return new PhisicDatas(position, new Dimension((int)(ghostRatio * stepX), (int)(ghostRatio * stepY)), new Velocity(), matrixPosition);
	}

	@Override
	protected void buildItem(PhisicDatas phisicDatas) {
		Entity ghost = new Ghost();
		gameModel.ghosts.add(ghost);

		initEntity(ghost, phisicDatas);
		
		addCollisionDetection(ghost, gameModel.pacman, new GhostCollidePacMan());
	}

}
