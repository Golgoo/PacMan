package model.game.entities;

import graphicmotor.GooContext;
import graphicmotor.animation.Animation;
import graphicmotor.animation.AnimationBank;
import singletons.Acessors;
import util.Direction;
import util.loader.sprite.SpriteEnum;
import util.loader.sprite.SpriteLoader;

public class Ghost extends Entity{

	@Override
	public int initGraphic() {
		GooContext GCtx = Acessors.getGctx();
		
		AnimationBank<Direction> animations = new AnimationBank<Direction>();
		animations.putAnimation(Direction.UP, new Animation(SpriteLoader.getRessourceStream(SpriteEnum.Enum.GHOST_UP_SPRITES, "classic"), 2, 80));
		animations.putAnimation(Direction.DOWN, new Animation(SpriteLoader.getRessourceStream(SpriteEnum.Enum.GHOST_DOWN_SPRITES, "classic"), 2, 80));
		animations.putAnimation(Direction.LEFT, new Animation(SpriteLoader.getRessourceStream(SpriteEnum.Enum.GHOST_LEFT_SPRITES, "classic"), 2, 80));
		animations.putAnimation(Direction.RIGHT, new Animation(SpriteLoader.getRessourceStream(SpriteEnum.Enum.GHOST_RIGHT_SPRITES, "classic"), 2, 80));
		
		int id = GCtx.createMultipleAnimatedEntity(animations);
		GCtx.enableEntity(id);
		
		return id ;
	}
}
