package model.game.entities;

import kernel.state.PrimalState;
import model.game.PhisicDatas;
import physic.Dimension;
import physic.Position;
import physic.Velocity;

public abstract class Entity {
	
	private int graphicId = -1 ;
	
	private PhisicDatas phisicDatas ;
	
	public abstract int initGraphic();
	
	protected PrimalState primalState ;
	
	public Position matrixPosition;
	
	public Entity() {
		graphicId = initGraphic();
	}
	
	public PrimalState getPrimalState() {
		return primalState;
	}
		
	public int getGraphicId() {
		return graphicId;
	}
	
	public PhisicDatas getPhisicDatas() {
		return phisicDatas ;
	}
	
	public void setPhisicDatas(PhisicDatas phisicDatas) {
		this.phisicDatas = phisicDatas;
	}
	
	public void setPosition(Position p) {
		phisicDatas.setPosition(p);
	}
	
	public void setDimension(Dimension d) {
		phisicDatas.setDimension(d);
	}
	
	public void setVelocity(Velocity v) {
		phisicDatas.setVelocity(v);
	}

	public void setVelocity(int vX, int vY) {
		Velocity vel = phisicDatas.getVelocity();
		vel.setxVel(vX);
		vel.setyVel(vY);
	}
}
