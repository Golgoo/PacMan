package model.game;

import physic.Dimension;
import physic.Position;
import physic.Velocity;

public class PhisicDatas {
	private Position position ;
	private Dimension dimension ;
	private Velocity velocity ;
	private Position matrixPosition;

	public PhisicDatas(Position position, Dimension dimension, Velocity velocity, Position matrixPosition) {
		this.position = position;
		this.dimension = dimension;
		this.velocity = velocity;
		this.matrixPosition = matrixPosition;
	}
	public Position getPosition() {
		return position;
	}
	public void setPosition(Position position) {
		this.position = position;
	}
	public Dimension getDimension() {
		return dimension;
	}
	public void setDimension(Dimension dimension) {
		this.dimension = dimension;
	}
	public Velocity getVelocity() {
		return velocity;
	}
	public void setVelocity(Velocity velocity) {
		this.velocity = velocity;
	}
	public Position getMatrixPosition() {
		return matrixPosition;
	}
	public void setMatrixPosition(Position matrixPosition) {
		this.matrixPosition = matrixPosition;
	}

	
}
