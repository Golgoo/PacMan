package kernel;

import graphicmotor.GooContext;
import kernel.state.SteroidPacState;
import model.game.entities.Entity;
import singletons.Acessors;

public class PacManCollideSteroid implements CollisionTreatment {

	@Override
	public void treatCollision(Entity pacman, Entity steroid) {
		GooContext GCtx = Acessors.getGctx();
		
		
		GCtx.destroyEntity(steroid.getGraphicId());
		Acessors.getPhysic().removeEntity(steroid);
		Acessors.getGameModel().steroids.remove(steroid);
		
		pacman.getPrimalState().setState(new SteroidPacState(pacman), 1000);
	}

}
