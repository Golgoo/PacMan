package kernel;


import model.game.GameModel;
import model.game.entities.Entity;
import singletons.Acessors;


public class GhostCollidePacMan implements CollisionTreatment {

	@Override
	public void treatCollision(Entity src, Entity dst) {
		GameModel gameModel = Acessors.getGameModel();
		if(gameModel.superPacman) {
			
		}else {
			gameModel.gameLoose = true ;
		}
	}

}
