package inputs.commands;

import kernel.Kernel;

public interface Command {
	public void launchKernelFunction(Kernel kernel);
}
