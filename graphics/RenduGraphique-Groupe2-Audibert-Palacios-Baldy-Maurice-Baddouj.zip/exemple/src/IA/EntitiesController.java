package IA;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import model.game.entities.Entity;

public class EntitiesController {
	private Map<Entity, List<EntityComportment>> entitiesMap = new HashMap<>();
	
	public void addEntityToCommand(Entity entity) {
		entitiesMap.put(entity, new LinkedList<EntityComportment>());
	}
	
	public void addEntityComportment(Entity entity, EntityComportment comportment) {
		List<EntityComportment> entityComportmentList = entitiesMap.get(entity);
		if(entityComportmentList == null) {
			addEntityToCommand(entity);
			entityComportmentList = entitiesMap.get(entity);
		}
		entityComportmentList.add(comportment);
	}
	
	public void apply() {
		for(Entity entity : entitiesMap.keySet()) {
			for(EntityComportment comportment : entitiesMap.get(entity))
				comportment.alterate(entity);
		}
	}
	
}
