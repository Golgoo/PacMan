package IA;

import java.util.List;

import graphicmotor.GooContext;
import model.game.GameModel;
import model.game.entities.Entity;
import pathfinding.AStar;
import pathfinding.Node;
import physic.Position;
import physic.Velocity;
import singletons.Acessors;
import util.Direction;

public class PathFindVelocityComportment implements EntityComportment{

	private Entity entityToFind ;
	private GameModel gameModel ;
	private GooContext GCtx ;
	
	private Direction lastWantedDir = null ;
	private Position lastWantedPos = null ;
	
	public PathFindVelocityComportment(Entity entityToFind) {
		this.entityToFind = entityToFind ;
		this.gameModel = Acessors.getGameModel();
		this.GCtx = Acessors.getGctx();
	}
	
	@Override
	public void alterate(Entity entity) {
		Position entityMatrixPosition = entity.getPhisicDatas().getMatrixPosition();
		Position entityToFindMatrixPosition = entityToFind.getPhisicDatas().getMatrixPosition();
		AStar aStar = new AStar(gameModel.getMatrix(), false);
		List<Node> nodes = aStar.findPathFromTo(entityMatrixPosition.getX(), entityMatrixPosition.getY(), entityToFindMatrixPosition.getX(), entityToFindMatrixPosition.getY());
		if(nodes != null && nodes.size() > 1) {
			Node firstNode = nodes.get(1);
			updateEntityVelocityToReach(entity, entityMatrixPosition ,firstNode.x, firstNode.y);
		}else {
			entity.setVelocity(new Velocity());
		}
	}

	private void updateEntityVelocityToReach(Entity entity, Position entityMatrixPosition, int x, int y) {
		Direction wantedDirection = null ;
		if(x < entityMatrixPosition.getX()) {
			wantedDirection = Direction.LEFT;
		}
		else if(x > entityMatrixPosition.getX()) {
			wantedDirection = Direction.RIGHT;
		}
		if(y < entityMatrixPosition.getY()) {
			wantedDirection = Direction.UP;
		}
		else if(y > entityMatrixPosition.getY()) {
			wantedDirection = Direction.DOWN;
		}
		
		boolean validMovment = false;
		if(wantedDirection == null) {
			validMovment = true;
		}
		else {
			if(lastWantedDir == null) {
				validMovment = true;
			}
			else if(wantedDirection == Direction.LEFT || wantedDirection == Direction.RIGHT) {
				if(lastWantedDir == Direction.LEFT || lastWantedDir == Direction.RIGHT) {
					validMovment = true;
				}else if(lastWantedPos.getX() == entityMatrixPosition.getX() && lastWantedPos.getY() == entityMatrixPosition.getY()) {
					validMovment = true;
				}
			}else {
				if(lastWantedDir == Direction.UP || lastWantedDir == Direction.DOWN) {
					validMovment = true;
				}
				else if(lastWantedPos.getX() == entityMatrixPosition.getX() && lastWantedPos.getY() == entityMatrixPosition.getY()) {
					validMovment = true;
				}
			}
		}

		Velocity entityVelocity = entity.getPhisicDatas().getVelocity();
		if(validMovment) {
			entityVelocity.setxVel(0);
			entityVelocity.setyVel(0);
			switch (wantedDirection) {
			case DOWN:
				entityVelocity.setyVel(1);
				break;
			case UP:
				entityVelocity.setyVel(-1);
				break;
			case LEFT:
				entityVelocity.setxVel(-1);
				break;
			case RIGHT:
				entityVelocity.setxVel(1);
			default:
				break;
			}
			
			lastWantedDir = wantedDirection ;
			lastWantedPos = new Position(x, y);
			
			if(wantedDirection != null)
				GCtx.setMultipledAnimatedEntityAnimation(entity.getGraphicId(), wantedDirection);
		}
	}

}
