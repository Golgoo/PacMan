package IA;

import model.game.entities.Entity;

public interface EntityComportment {
	public void alterate(Entity entity);
}
