package test.visual;

import javax.swing.JFrame;

import graphicmotor.GooContext;

public class VisualTestFactory {
	public static GooContext createTestContext(int width, int height) {
		GooContext GCtx = new GooContext(width, height);

		JFrame frame = new JFrame();
		frame.setSize(width, height);
		frame.add(GCtx.getCanvas());
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GCtx.start(60);
		
		return GCtx;
	}
}
