package test.visual;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;


import graphicmotor.GooContext;
import graphicmotor.animation.Animation;
import graphicmotor.animation.AnimationBank;

class ChangeAnimationTest {

	public static void main(String args[]) {
		
		GooContext GCtx = VisualTestFactory.createTestContext(600, 800);
		
		AnimationBank<Integer> animationBank = new AnimationBank<Integer>();
		try {
			animationBank.putAnimation(1, new Animation(new FileInputStream(new File("src/sprites_1.png")), 6, 80));
			animationBank.putAnimation(2, new Animation(new FileInputStream(new File("src/sprites_1.png")), 3, 80));
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		
		int ref = GCtx.createMultipleAnimatedEntity(animationBank);
		GCtx.setEntityPosition(ref, 250, 350);
		GCtx.setEntitySize(ref, 100, 100);
		GCtx.enableEntity(ref);
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		GCtx.setMultipledAnimatedEntityAnimation(ref, 2);
	}

}
