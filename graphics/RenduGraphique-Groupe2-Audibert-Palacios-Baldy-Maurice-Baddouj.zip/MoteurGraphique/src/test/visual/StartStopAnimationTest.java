package test.visual;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import graphicmotor.GooContext;
import graphicmotor.animation.Animation;

public class StartStopAnimationTest {
	
	public static void main(String[] args) {
		
		GooContext GCtx = VisualTestFactory.createTestContext(600, 800);
		
		int ref ;
		try {
			ref = GCtx.createSingleAnimatedEntity(new Animation(new FileInputStream(new File("src/sprites_1.png")), 6, 80));
			GCtx.setEntityPosition(ref, 250, 350);
			GCtx.setEntitySize(ref, 100, 100);
			GCtx.enableEntity(ref);
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			GCtx.stopEntityAnimation(ref);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			GCtx.startEntityAnimation(ref);
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
	}
}
