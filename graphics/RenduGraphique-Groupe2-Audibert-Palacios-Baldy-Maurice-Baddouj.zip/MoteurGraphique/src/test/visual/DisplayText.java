package test.visual;

import java.awt.Font;

import graphicmotor.GooContext;

public class DisplayText {
	public static void main(String args[]) {
		GooContext GCtx = VisualTestFactory.createTestContext(400, 400);
		
		int id = GCtx.createTextEntity(new Font("Verdana", Font.BOLD, 36));
		GCtx.setText(id, "Hello World");
		GCtx.setEntityColorMask(id, 1.0f, 0.4f, 0.6f);
		GCtx.enableEntity(id);
		GCtx.setEntityPosition(id, 50, 200);
	}
}
