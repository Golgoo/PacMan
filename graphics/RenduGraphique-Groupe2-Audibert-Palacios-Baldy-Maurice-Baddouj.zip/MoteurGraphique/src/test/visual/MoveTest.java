package test.visual;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Timer;
import java.util.TimerTask;

import graphicmotor.GooContext;
import graphicmotor.animation.Animation;

public class MoveTest {
	

	
	public static void main(String args[]) {
		GooContext GCtx = VisualTestFactory.createTestContext(500, 400);
		
		
		
		try {
			int id = GCtx.createSingleAnimatedEntity(new Animation(new FileInputStream(new File("src/sprites_1.png")), 6, 60));
			GCtx.setEntityPosition(id, 0, 300 / 2 - 50);
			GCtx.setEntitySize(id, 70, 100);
			GCtx.enableEntity(id);
			
			Timer timer = new Timer();
			TimerTask task = new TimerTask() {
				
				private boolean toRight = true;
				private boolean toDown = true;
				private int xVel = 2 ;
				private int yVel = 1 ;
				private int x = 0;
				private int y = 300 / 2 - 50;
				
				@Override
				public void run() {
					if(toRight) {
						if(xVel + x + 70> 500) {
							toRight = false;
							xVel = -xVel;
						}
					}else {
						if(x - xVel < 0) {
							toRight = true;
							xVel = -xVel;
						}
					}
					x += xVel ;
					if(toDown) {
						if(yVel + y + 100> 400) {
							toDown = false;
							yVel = -yVel;
						}
					}else {
						if(y - yVel < 0) {
							toDown = true;
							yVel = -yVel;
						}
					}
					y += yVel ;
					GCtx.setEntityPosition(id, x, y);
				}
			};
			timer.schedule(task, 0, 15);
			
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
}
