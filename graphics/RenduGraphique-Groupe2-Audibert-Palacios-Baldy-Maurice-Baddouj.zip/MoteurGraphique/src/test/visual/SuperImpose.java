package test.visual;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import graphicmotor.GooContext;
import graphicmotor.animation.Animation;

public class SuperImpose {
	public static void main(String args[]) throws FileNotFoundException {
		GooContext Gctx = VisualTestFactory.createTestContext(600, 600);
		
		int id1 = Gctx.createSingleAnimatedEntity(new Animation(new FileInputStream(new File("src/sprites_1.png")), 6, 80));
		int id2 = Gctx.createSingleAnimatedEntity(new Animation(new FileInputStream(new File("src/sprites_1.png")), 6, 80));
		
		Gctx.setEntityPosition(id1, 200, 200);
		Gctx.setEntityColorMask(id1, 0.8f, 0.1f, 0.7f);
		Gctx.setEntitySize(id1, 200, 200);
		Gctx.setZIndex(id1, 2);
		Gctx.enableEntity(id1);
		
		Gctx.setEntityPosition(id2, 250, 250);
		Gctx.setEntityColorMask(id2, 0.8f, 0.8f, 0.2f);
		Gctx.setEntitySize(id2, 75, 100);
		Gctx.setZIndex(id2, 3);
		Gctx.enableEntity(id2);
	}
}
