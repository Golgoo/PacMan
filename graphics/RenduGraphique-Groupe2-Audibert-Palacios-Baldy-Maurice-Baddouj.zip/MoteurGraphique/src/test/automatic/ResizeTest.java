package test.automatic;

import java.io.File;
import java.io.FileInputStream;

import com.jogamp.opengl.GL2;

import graphicmotor.GooContext;
import test.AutomaticTest;

public class ResizeTest extends AutomaticTest{

	public ResizeTest(GooContext gooContext) {
		super(gooContext);
	}

	@Override
	public String getName() {
		return "ResizeTest";
	}
	
	private int x = 200, y = 200 ;
	
	
	private int w1 = 150, h1 = 180 ;
	private int w2 = 80, h2 = 80 ;
	
	
	@Override
	protected void tryToInit() throws Exception {
		int ref = gooContext.createStaticEntity(new FileInputStream(new File("src/red.png")));
		gooContext.setEntityPosition(ref, x, y);
		gooContext.setEntitySize(ref, w1, h1);
		gooContext.enableEntity(ref);
		
		gooContext.setEntitySize(ref, w2, h2);
	}

	@Override
	protected void launchTest(GL2 gl) throws Exception {
		float [] rgb = readRGBAt(gl, x + w2 + (w1 - w2)/2, convertY(y + h2 + (h1 - h2)/ 2));
		
		assertInBounds(rgb[0], 0.0f, 0.02f);
		assertInBounds(rgb[1], 0.0f, 0.02f);
		assertInBounds(rgb[2], 0.0f, 0.02f);
		
		rgb = readRGBAt(gl, x + w2/2, convertY(y + h2/2));
		assertInBounds(rgb[0], 1.0f, 0.02f);
	}

}
