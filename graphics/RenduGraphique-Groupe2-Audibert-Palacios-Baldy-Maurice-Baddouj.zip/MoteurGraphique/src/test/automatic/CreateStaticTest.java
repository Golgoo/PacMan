package test.automatic;

import java.io.File;
import java.io.FileInputStream;
import java.nio.ByteBuffer;

import com.jogamp.opengl.GL2;

import graphicmotor.GooContext;
import test.AutomaticTest;

public class CreateStaticTest extends AutomaticTest {

	public CreateStaticTest(GooContext gooContext) {
		super(gooContext);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getName() {
		return "CreateOneStaticTest";
	}

	@Override
	protected void tryToInit() throws Exception {
		int entityId = gooContext.createStaticEntity(new FileInputStream(new File("src/red.png")));
		gooContext.setEntityPosition(entityId, 0, 0);
		gooContext.setEntitySize(entityId, gooContext.getCanvas().getWidth(), gooContext.getCanvas().getHeight());
		gooContext.enableEntity(entityId);
	}

	@Override
	protected void launchTest(GL2 gl) throws Exception {
		ByteBuffer RGB = getColorAt(gl, gooContext.getCanvas().getWidth() / 2, gooContext.getCanvas().getHeight() / 2);
    	
    	float r, g, b ;
    	r = readR(RGB);
    	g = readG(RGB);
    	b = readB(RGB);
    	
    	assertInBounds(r, 1.0f, 0.01f);
    	assertInBounds(g, 0.0f, 0.01f);
    	assertInBounds(b, 0.0f, 0.01f);
	}

}
