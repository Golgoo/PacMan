package test.automatic;

import java.io.File;
import java.io.FileInputStream;

import com.jogamp.opengl.GL2;

import graphicmotor.GooContext;
import test.AutomaticTest;

public class EnableDisableTest extends AutomaticTest{

	public EnableDisableTest(GooContext gooContext) {
		super(gooContext);
	}

	@Override
	public String getName() {
		return "Enable/Disable Test";
	}
	
	private int x = 200 ;
	private int y = 200 ;
	private int w = 50 ; 
	private int h = 50 ;
	
	private int x2 = 400 ;
	private int y2 = 400 ;

	@Override
	protected void tryToInit() throws Exception {
		int ref = gooContext.createStaticEntity(new FileInputStream(new File("src/red.png")));
		gooContext.setEntityPosition(ref, x, y);
		gooContext.setEntitySize(ref, w, h);
		gooContext.disableEntity(ref);
		gooContext.enableEntity(ref);
		gooContext.disableEntity(ref);
		gooContext.enableEntity(ref);
		gooContext.enableEntity(ref);
		gooContext.disableEntity(ref);
		
		int ref2 = gooContext.createStaticEntity(new FileInputStream(new File("src/red.png")));
		gooContext.setEntityPosition(ref2, x2, y2);
		gooContext.setEntitySize(ref2, w, h);
		gooContext.disableEntity(ref2);
		gooContext.enableEntity(ref2);
		gooContext.disableEntity(ref2);
		gooContext.enableEntity(ref2);
		gooContext.enableEntity(ref2);
		gooContext.disableEntity(ref2);
		gooContext.enableEntity(ref2);
	}

	@Override
	protected void launchTest(GL2 gl) throws Exception {
		float[] rgb = readRGBAt(gl, x + w / 2 , convertY(y + h / 2) );
		assertNotInBounds(rgb[0], 1.0f, 0.02f);
		
		
		rgb = readRGBAt(gl, x2 +w/2, convertY(y2 + h/2));
		assertInBounds(rgb[0], 1.0f, 0.02f);
	}

}
