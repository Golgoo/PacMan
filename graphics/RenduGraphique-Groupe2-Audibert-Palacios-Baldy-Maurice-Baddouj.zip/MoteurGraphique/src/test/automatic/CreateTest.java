package test.automatic;

import java.io.File;
import java.io.FileInputStream;
import java.nio.ByteBuffer;

import com.jogamp.opengl.GL2;

import graphicmotor.GooContext;
import test.AutomaticTest;

public class CreateTest extends AutomaticTest{
	public CreateTest(GooContext gooContext) {
		super(gooContext);
	}

	@Override
	public String getName() {
		return "CreateTest";
	}

	@Override
	protected void tryToInit() throws Exception {
		int entityId = gooContext.createStaticEntity(new FileInputStream(new File("src/green.png")));
		gooContext.setEntityPosition(entityId, 0, 0);
		gooContext.setEntitySize(entityId, gooContext.getCanvas().getWidth(), gooContext.getCanvas().getHeight());
		gooContext.enableEntity(entityId);
	}

	@Override
	protected void launchTest(GL2 gl) throws Exception {
		ByteBuffer RGB = getColorAt(gl, gooContext.getCanvas().getWidth() / 2, gooContext.getCanvas().getHeight() / 2);
    	
    	float g ;
    	g = readG(RGB);
    	    	
    	assertInBounds(g, 1.0f, 0.01f);
	}
}
