package test.automatic;

import java.io.File;
import java.io.FileInputStream;

import com.jogamp.opengl.GL2;

import graphicmotor.GooContext;
import test.AutomaticTest;

public class DeleteTest extends AutomaticTest {

	public DeleteTest(GooContext gooContext) {
		super(gooContext);
	}

	@Override
	public String getName() {
		return "DeleteOneTest";
	}
	
	private int x = 200 ;
	private int y = 200 ;
	private int w = 50 ; 
	private int h = 50 ;

	@Override
	protected void tryToInit() throws Exception {
		int ref = gooContext.createStaticEntity(new FileInputStream(new File("src/red.png")));
		gooContext.setEntityPosition(ref, x, y);
		gooContext.setEntitySize(ref, w, h);
		gooContext.enableEntity(ref);
		gooContext.destroyEntity(ref);
	}

	@Override
	protected void launchTest(GL2 gl) throws Exception {
		float[] rgb = readRGBAt(gl, x + w / 2 , convertY(y + h / 2) );

		assertNotInBounds(rgb[0], 1.0f, 0.02f);
	}
	
}
