package test;


import javax.swing.JFrame;

import org.junit.jupiter.api.Test;

import graphicmotor.GooContext;
import test.automatic.ColorTest;
import test.automatic.CreateStaticTest;
import test.automatic.CreateTest;
import test.automatic.DeleteTest;
import test.automatic.EnableDisableTest;
import test.automatic.ResizeTest;
import test.automatic.ZIndexTest;

class TestAll {
	
	
	private static int FPS = 60 ;

	@Test
	public void apparitionTest() {
		
		GooContext GCTx = new GooContext(600, 800);
		
		GLTest glTest = (GLTest) GCTx.glListener;
				
		GCTx.start(FPS);
		
		JFrame frame = new JFrame();
		frame.setSize(600, 800);
		frame.add(GCTx.getCanvas());
		frame.setVisible(true);
		
		glTest.addTest(new ColorTest(GCTx));
		glTest.addTest(new ZIndexTest(GCTx));
		glTest.addTest(new CreateStaticTest(GCTx));
		glTest.addTest(new CreateTest(GCTx));
		glTest.addTest(new DeleteTest(GCTx));
		glTest.addTest(new EnableDisableTest(GCTx));
		glTest.addTest(new ResizeTest(GCTx));

		while(glTest.isTesting()) {
			Thread.yield();
		}
		try {Thread.sleep(50);} catch (InterruptedException e) {}
		GCTx.clear();
		GCTx.stop();
	}


}
